package com.example.jimmy.makingagame;

public interface MovingObjects {
    int getX();
    int getY();
    int getWidth();
    int getHeight();
}
