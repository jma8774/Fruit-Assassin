package com.example.jimmy.makingagame;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;

public class GameActivity extends Activity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e("Debug: ", "CREATED GAME ACTIVITY");
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        this.requestWindowFeature(getWindow().FEATURE_NO_TITLE);
        gameView = new GameView(this);
        setContentView(gameView);



        Log.e("DEBUG:", "NEW GAME CREATED");
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    public void onDestroy() {
        Log.e("Debug: ", "DESTROYED");
        super.onDestroy();
        boolean retry = true;
        while (retry) {
            try {
                gameView.getMainThread().setRunning(false);
                gameView.getMainThread().join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.setPaused(true);
        Log.e("Debug: ", "PAUSED");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("Debug: ", "RESUMED");
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();

        switch(action) {
            case MotionEvent.ACTION_DOWN:
                if(gameView.getShootKnife() == false) {
                    gameView.setShootKnife(true);
                }
                if(gameView.getGameEnded()) {
                    Intent intent = getIntent();
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    finish();
                    startActivity(intent);
                    Log.e("DEBUG:", "RESTART");
                }
        }
        return true;
    }

}
