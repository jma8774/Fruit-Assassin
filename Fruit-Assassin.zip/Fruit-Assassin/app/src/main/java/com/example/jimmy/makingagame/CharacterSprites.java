package com.example.jimmy.makingagame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class CharacterSprites implements MovingObjects {

    private final int initialX;
    private final int initialY;
    private Bitmap image;
    private int x;
    private int y;
    private int width;
    private int height;
    private int yVelo;
    private int xVelo;
    private boolean isKnife;

    public CharacterSprites(Bitmap image, int x, int y){
        isKnife = false;
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
        this.x = x;
        this.y = y;
        this.initialX = x;
        this.initialY = y;
        this.yVelo = 0;
        this.xVelo = 0;
    }

    public CharacterSprites(Bitmap image, int x, int y, int xVelo, int yVelo){
        isKnife = false;
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
        this.x = x;
        this.y = y;
        this.initialX = x;
        this.initialY = y;
        this.yVelo = yVelo;
        this.xVelo = xVelo;
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(image, x, y, null);

//        Rect rect = new Rect(x, y, x + width, y + height);
//        Paint paint = new Paint();
//        paint.setColor(Color.BLACK);
//        paint.setStrokeWidth(5);
//        paint.setStyle(Paint.Style.STROKE);
//        canvas.drawRect(rect, paint);
    }

    public void update() {
        y += yVelo;
        x += xVelo;
    }

    public void setKnife(boolean knife) {
        this.isKnife = knife;
    }

    public void returnToStart() {
        x = initialX;
        y = initialY;
    }

    public boolean checkCollision(MovingObjects others) {
        if(!isKnife) return false;

        int kX = this.getX() + this.width / 2;
        int kY = this.getY() + this.height / 2;
        int oWidth = others.getWidth() - 50;
        int oHeight = others.getHeight();
        int oX = others.getX();
        int oY = others.getY();

        if(kX > oX && kX < oX + oWidth) {
            if(kY > oY && kY < oY + oHeight) {
                return true;
            }
        }
        return false;
    }

    public void setyVelo(int yVelo) {
        this.yVelo = yVelo;
    }

    public int getYVelo() {
        return yVelo;
    }

    public void setBitmap(Bitmap bitmap) {
        image = bitmap;
    }

    public Bitmap getBitmap() {
        return image;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }
}