package com.example.jimmy.makingagame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;

public class Background {
    private Bitmap image;
    private Rect src;
    private int x;
    private int y;

    public Background(Bitmap image) {
        this.image = image;
        src = new Rect(0, 0, image.getWidth(), image.getHeight());
    }

    public void draw(Canvas canvas) {
        RectF dist = new RectF(0, 0, canvas.getWidth(), canvas.getHeight());
        canvas.drawBitmap(image, src, dist, null);
    }

    public void update() {

    }
}
