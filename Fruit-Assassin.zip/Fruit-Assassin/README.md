# Fruit Assassin
[![Watch the video](https://i.gyazo.com/3837bcf60064ded304b8c44ce41222cb.png)](https://streamable.com/3l81i)

> Android game that I made for fun using Java in Android Studio
> Watch the video! (Ignore the voice in the video, I was in a voice call with my friends)

Because I have a problem commiting Java files onto GitHub, this repository does not contain the whole project. However you can download it from the [zip file](https://github.com/jma8774/Fruit-Cutter/blob/master/Fruit%20Cutter.zip) here.
