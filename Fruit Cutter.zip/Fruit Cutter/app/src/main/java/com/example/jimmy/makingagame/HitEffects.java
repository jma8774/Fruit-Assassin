package com.example.jimmy.makingagame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;

public class HitEffects {
    private CharacterSprites[] particles;
    private long timeStart;
    private boolean disappear;

    public HitEffects(Bitmap image, int x, int y) {
        particles = new CharacterSprites[(int)(Math.random() * 10) + 10];
        timeStart = System.currentTimeMillis();

        for(int i = 0; i < particles.length; i ++) {
            int xVelo = (int)(Math.random()*10) - 5;
            int yVelo = (int)(Math.random()*10) - 5;
            while(xVelo == 0)
                xVelo = (int)(Math.random()*10) - 5;
            while(yVelo == 0)
                yVelo = (int)(Math.random()*10) - 5;
            particles[i] = new CharacterSprites(image, x, y, xVelo, yVelo);
        }
    }

    public void update() {
        for(int i = 0; i < particles.length; i ++) {
            CharacterSprites temp = particles[i];
            temp.update();
//            temp.setBitmap(rotate(temp.getBitmap()));
        }
    }

    public void draw(Canvas canvas) {
        if(!(System.currentTimeMillis() - timeStart > 1000)) {
            for (int i = 0; i < particles.length; i++) {
                particles[i].draw(canvas);
            }
        } else {
            disappear = true;
        }
    }

    public Bitmap rotate(Bitmap src) {
        Matrix matrix = new Matrix();
        matrix.postRotate((int)(Math.random()*2 + 1));
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
    }

    public boolean getDisappear() {
        return disappear;
    }
}
