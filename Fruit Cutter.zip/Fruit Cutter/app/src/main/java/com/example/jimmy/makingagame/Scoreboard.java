package com.example.jimmy.makingagame;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.util.Log;

public class Scoreboard {
    private int x;
    private int y;
    private int score;
    private Paint paint;
    private GameView gameView;
    private DisplayMetrics metrics;

    public Scoreboard(GameView gameView) {
        this.gameView = gameView;
        metrics = gameView.getContext().getResources().getDisplayMetrics();
        int screenWidth = metrics.widthPixels;
        int screenHeight = metrics.heightPixels;
        this.x = screenWidth / 2;
        this.y = screenHeight / 2;
        score = 0;

        paint = new Paint();
        Typeface font = Typeface.createFromAsset(gameView.getContext().getAssets(), "fonts/pixel.ttf");
        paint.setTypeface(font);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    public void draw(Canvas canvas) {
        paint.setColor(Color.parseColor("#6fcbff"));
        float scaledSizeInPixels = 100 * metrics.scaledDensity;
        paint.setTextSize(scaledSizeInPixels);
        canvas.drawText("" + score, x, y, paint);

        if(gameView.getGameEnded()) {
            Log.e("DEBUG: ", "UPDATE END SCOREBOARD");

            SharedPreferences prefs = gameView.getContext().getSharedPreferences("Apple Game", Context.MODE_PRIVATE);
            if(score > prefs.getInt("Best Score", 0)) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt("Best Score", score);
                editor.commit();
                MainMenuActivity.setHighScore(score);
            }

            paint.setColor(Color.parseColor("#fd6161"));
            scaledSizeInPixels = 25 * metrics.scaledDensity;
            paint.setTextSize(scaledSizeInPixels);
            canvas.drawText("Best: " +  MainMenuActivity.getHighScore(), x, y + 50 * metrics.scaledDensity, paint);
        }
    }

    public void increment() {
        this.score ++;
    }

    public int getScore() {return score;}
}
