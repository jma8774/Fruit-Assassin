package com.example.jimmy.makingagame;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainMenuActivity extends Activity {

    private static int highScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        SharedPreferences prefs = this.getSharedPreferences("Apple Game", Context.MODE_PRIVATE);
        highScore = prefs.getInt("Best Score", 0);

        Button button = (Button) findViewById(R.id.button);
        TextView textView = (TextView) findViewById(R.id.score);
        Typeface font = Typeface.createFromAsset(getAssets(), "fonts/pixel.ttf");
        button.setTypeface(font);
        textView.setTypeface(font);
        textView.setText("Best: " + highScore);


        Log.e("DEBUG: ", "MAIN MENU ACTIVITY");
    }

    public void createGame(View v) {
        Log.e("DEBUG: ", "BUTTON PRESSED");
        Intent intent = new Intent(MainMenuActivity.this, GameActivity.class);
        startActivity(intent);
    }


    public static int getHighScore() {
        return highScore;
    }

    public static void setHighScore(int highScore) {
        MainMenuActivity.highScore = highScore;
    }
}
