package com.example.jimmy.makingagame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;

public class Duck implements MovingObjects{

    private Bitmap duckFrames;
    private Context context;
    private int x;
    private int y;
    private int width;
    private int height;
    private int xVelo;
    private int direction;
    private static final int LEFT = 0;
    private static final int RIGHT = 1;
    private Bitmap[] ducks;
    private Bitmap currentFrame;
    private int frameNum;
    private boolean isNewFrame;
    private long timeNow;

    public Duck(GameView gameView, int pos) {
        this.context = gameView.getContext();
        duckFrames = BitmapFactory.decodeResource(context.getResources(), R.drawable.duck);
        ducks = new Bitmap[2];
        ducks[0] = Bitmap.createBitmap(duckFrames, 0, 0, duckFrames.getWidth(), duckFrames.getHeight() / 2);
        ducks[1] = Bitmap.createBitmap(duckFrames, 0, duckFrames.getHeight() / 2, duckFrames.getWidth(), duckFrames.getHeight() / 2);

        width = ducks[0].getWidth();
        height = ducks[0].getHeight();

        this.x = 0 - width;
        this.y = context.getResources().getDisplayMetrics().heightPixels / 5 + ((int)(height * .85) * pos);
        this.xVelo = (int)(Math.random()*10) + 5;
        direction = RIGHT;

        frameNum = 0;
        isNewFrame = false;
        currentFrame = ducks[frameNum];
        timeNow = System.currentTimeMillis();
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(currentFrame, x, y, null);

//        Rect rect = new Rect(x, y, x + width, y + height);
//        Paint paint = new Paint();
//        paint.setColor(Color.BLACK);
//        paint.setStrokeWidth(5);
//        paint.setStyle(Paint.Style.STROKE);
//        canvas.drawRect(rect, paint);
    }

    public void update() {
        if(System.currentTimeMillis() - timeNow > 350) {
            frameNum++;
            frameNum%=2;
            currentFrame = ducks[frameNum];
            isNewFrame = true;
            timeNow = System.currentTimeMillis();
        }

        x += xVelo;
        if(x > context.getResources().getDisplayMetrics().widthPixels) {
            this.xVelo = -1 * ((int)(Math.random()*10) + 5);
        } else if(x + width < 0) {
            this.xVelo = (int)(Math.random()*10) + 5;
        }

        if(xVelo < 0 && isNewFrame) {
            currentFrame = flipDuck(currentFrame);
            isNewFrame = false;
        } else if(xVelo > 0){
            currentFrame = ducks[frameNum];
        }
    }

    public Bitmap flipDuck(Bitmap src) {
        Matrix matrix = new Matrix();
        matrix.postRotate(180);
        matrix.postScale(1, -1, width / 2, height / 2);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }
}
