package com.example.jimmy.makingagame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private DisplayMetrics metric;
    private int screenWidth;
    private int screenHeight;
    private MainThread thread;
    private CharacterSprites knife;
    private CharacterSprites apple;
    private ArrayList<Duck> ducks;
    private Background background;
    private Scoreboard scoreboard;
    private Bitmap applePiece;
    private Bitmap bDuckFeather;
    private Bitmap bApple;
    private ArrayList<HitEffects> appleEffects;
    private HitEffects duckEffect;
    private boolean shootKnife;
    private boolean gameEnded;
    private boolean paused;
    private static MediaPlayer appleSound;
    private static MediaPlayer duckSound;

    public GameView(Context context) {
        super(context);
        Log.e("Debug: ", "GameView CREATED");

        getHolder().addCallback(this);

        metric = getContext().getResources().getDisplayMetrics();
        screenWidth = metric.widthPixels;
        screenHeight = metric.heightPixels;

        appleEffects = new ArrayList<HitEffects>();
        ducks = new ArrayList<Duck>();
        thread = new MainThread(getHolder(), this);
        setFocusable(true);

        appleSound = MediaPlayer.create(getContext(), R.raw.hit_apple);
        duckSound = MediaPlayer.create(getContext(), R.raw.hit_duck);

        shootKnife = false;
        gameEnded = false;
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.e("Debug: ", "SURFACE CREATED");

        paused = false;
        thread.setRunning(true);
        if(thread.getState() == Thread.State.NEW) {
            applePiece = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.apple_slice), 96, 96, false);
            bDuckFeather = BitmapFactory.decodeResource(getResources(), R.drawable.duck);

            Bitmap bKnife = BitmapFactory.decodeResource(getResources(), R.drawable.knife);
            bApple = BitmapFactory.decodeResource(getResources(), R.drawable.apple);
            bKnife = Bitmap.createScaledBitmap(bKnife, 64, 192, false);
            bApple = Bitmap.createScaledBitmap(bApple, 192, 192, false);
            knife = new CharacterSprites(bKnife, screenWidth / 2 - bKnife.getWidth() / 2, screenHeight - bKnife.getHeight() - screenHeight / 10, 0, -35);
            knife.setKnife(true);
            apple = new CharacterSprites(bApple, screenWidth / 2 - bApple.getWidth() / 2, screenHeight / 10);

            background = new Background(BitmapFactory.decodeResource(getResources(), R.drawable.background));
            scoreboard = new Scoreboard(this);

            ducks.add(new Duck(this, ducks.size()));
            thread.start();
        }
        if(gameEnded) {
            Canvas canvas = holder.lockCanvas();
            draw(canvas);
            holder.unlockCanvasAndPost(canvas);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.e("Debug: ", "SURFACE DESTROYED");
    }

    public void update() {
        if(shootKnife)
            knife.update();
        if(appleEffects.size() != 0) {
            for(int i = 0; i < appleEffects.size(); i ++) {
                if(appleEffects.get(i).getDisappear()) {
                    appleEffects.remove(i);
                    i --;
                } else
                    appleEffects.get(i).update();
            }
        }
        if(knife.checkCollision(apple)) {
            shootKnife = false;
            appleEffects.add(new HitEffects(applePiece, screenWidth / 2 - applePiece.getWidth() / 2, screenHeight / 10));
            knife.returnToStart();
            appleSound.start();
            scoreboard.increment();
        }
        if((double) scoreboard.getScore() / 5 == ducks.size() && ducks.size() < 4) {
            ducks.add(new Duck(this, ducks.size()));
        }
        for (int i = 0; i < ducks.size(); i++) {
            ducks.get(i).update();
            if (knife.checkCollision(ducks.get(i))) {
                duckSound.start();
                shootKnife = false;
                gameEnded = true;
            }
        }
}

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if(canvas != null) {
            background.draw(canvas);
            scoreboard.draw(canvas);
            apple.draw(canvas);
            knife.draw(canvas);

            for(int i = 0; i < ducks.size(); i ++) {
                ducks.get(i).draw(canvas);
            }

            if(appleEffects.size() != 0) {
                 for(int i = 0; i < appleEffects.size(); i ++)
                     appleEffects.get(i).draw(canvas);
            }
        }
    }

    public MainThread getMainThread() {
        return thread;
    }

    public boolean getShootKnife() {
        return shootKnife;
    }

    public void setShootKnife(boolean shootKnife) {
        this.shootKnife = shootKnife;
    }

    public boolean getGameEnded() {
        return gameEnded;
    }

    public void setPaused(boolean paused){
        this.paused = paused;
    }

    public boolean getPaused() {
        return paused;
    }
}
